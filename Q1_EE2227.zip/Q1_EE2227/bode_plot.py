import numpy as np
from scipy import signal
from matplotlib import pyplot as plt
 

num = [1]

den = [1, 0.1, 1]
 

R = np.arange(0.1,1.1,0.1)
 
f1 = plt.figure()
for i in range(0,9):
    den = [1, 2*R[i], 1]
print (den)
s1 = signal.lti(num, den)
    
w, mag, phase = signal.bode(s1, np.arange(0.1, 5, 0.01).tolist())
plt.semilogx (w, mag, color="blue", linewidth="1")
plt.xlabel ("Frequency")
plt.ylabel ("Magnitude")

 
plt.figure()
 
for i in range(0,9):
    den = [1, R[i], 1]
s1 = signal.lti(num, den)
w, mag, phase = signal.bode(s1, np.arange(0.1, 10, 0.02).tolist())
plt.semilogx (w, phase, color="red", linewidth="1.1")
plt.xlabel ("Frequency")
plt.ylabel ("Phase")

plt.show()