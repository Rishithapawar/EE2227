import numpy as np
import matplotlib.pyplot as plt 
x= np.linspace(-2,1,4)

d=[]

p = np.poly1d([1,2,9,1]) #coefficients of transfer function

c=np.append(d,p)

m = np.zeros((4,3))

try:
	for i in range(len(m[1])):
		m[0][i] = c[2*i]
except IndexError:
	print(".")

try:
	for i in range(len(m[1])):
		m[1][i] = c[2*i+1]
except IndexError:
	print(".")
for j in range(2,len(m)):	
	try:
		for i in range(len(m[i])):
			m[j][i] = (m[j-2+1][0]*m[j-2+0][i+1]-m[j-2+0][0]*m[j-2+1][i+1])/m[j-2+1][0]
	except IndexError:
		print(".")
		
z = 0
for i in range(1,len(m)):
	if(m[i][0]<0):
		z = z + 1
print("ROUTH ARRAY FOR GIVEN TRANSFER FUNCTION IS:")
print(m)	
if(z > 0):
	print("SYSTEM IS NOT STABLE")
elif(z == 0):
	print("SYSTEM IS STABLE")			